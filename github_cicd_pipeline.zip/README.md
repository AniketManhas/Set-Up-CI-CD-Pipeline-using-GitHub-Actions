# CI/CD Pipeline Example using GitHub Actions

This project demonstrates how to set up a simple CI/CD pipeline using GitHub Actions for Python testing and deployment.