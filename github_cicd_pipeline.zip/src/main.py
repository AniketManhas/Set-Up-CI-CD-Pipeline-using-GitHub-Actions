def add(a, b):
    return a + b

if __name__ == "__main__":
    print("Result:", add(2, 3))
